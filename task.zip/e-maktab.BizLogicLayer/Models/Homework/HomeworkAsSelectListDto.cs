﻿

namespace e_maktab.BizLogicLayer.Models;

public class HomeworkAsSelectListDto
{
    public int Id { get; set; }
    public int StateId { get; set; }
    public string Title { get; set; }
}
