﻿using e_maktab.BizLogicLayer.Pagination;
using WEBASE.Models;

namespace e_maktab.BizLogicLayer.Models;

public class RoleListSortFilterOptions:PaginationParams
{

}
