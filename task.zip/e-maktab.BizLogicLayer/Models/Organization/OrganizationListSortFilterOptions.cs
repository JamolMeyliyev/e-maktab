﻿using e_maktab.BizLogicLayer.Pagination;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WEBASE.Models;

namespace e_maktab.BizLogicLayer.Models.Organization;

public class OrganizationListSortFilterOptions : PaginationParams
{
}
