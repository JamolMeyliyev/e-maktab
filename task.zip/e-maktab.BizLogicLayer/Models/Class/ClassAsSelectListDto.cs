﻿

namespace e_maktab.BizLogicLayer.Models;
public class ClassAsSelectListDto 
{
    public int Id { get; set; }
    public string ShortName { get; set; }
    public int StateId { get; set; }
}
