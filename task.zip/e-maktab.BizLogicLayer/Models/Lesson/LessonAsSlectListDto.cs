﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace e_maktab.BizLogicLayer.Models;

public class LessonAsSlectListDto
{
    public int Id { get; set; }
    public int StateId { get; set; }
    public string Name { get; set; }
}
