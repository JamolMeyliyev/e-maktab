﻿using e_maktab.Core.Options;
using Microsoft.AspNetCore.Mvc;

namespace e_maktab.Attributes;

//[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
//public class CustomAuthorizeAttribute : TypeFilterAttribute
//{
//    public override void OnAuthorization(AuthorizationContext filterContext)
//    {
//    }
