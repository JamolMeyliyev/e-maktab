﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace e_maktab.Controllers.Admin;

[Route("api/[controller]")]
[ApiController]
public class ModuleController : ControllerBase
{
}
