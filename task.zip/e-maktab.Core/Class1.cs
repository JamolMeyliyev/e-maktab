﻿namespace e_maktab.Core
{
    public class Class1
    {

    }
}