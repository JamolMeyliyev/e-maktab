﻿

using e_maktab.DataLayer.Entities;

namespace e_maktab.DataLayer.Repositories;

public interface ITeacherRepository:IGenericRepository<Teacher>
{
}
